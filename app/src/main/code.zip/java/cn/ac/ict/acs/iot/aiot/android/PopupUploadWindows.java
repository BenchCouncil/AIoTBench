package cn.ac.ict.acs.iot.aiot.android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PopupUploadWindows extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup_upload_windows);
    }
}